import type { Alert, Encounter } from '../types'
export const encounters: Encounter[] = [
  {id:'AL-2048',patient:'Ananya Sharma',age:54,complaint:'Severe chest discomfort',severity:'Critical',status:'Awaiting review',time:'Now'},
  {id:'AL-2047',patient:'Rohan Mehta',age:31,complaint:'Persistent fever',severity:'Attention',status:'Intake complete',time:'8 min'},
  {id:'AL-2046',patient:'Meera Joshi',age:67,complaint:'Medication follow-up',severity:'Routine',status:'In review',time:'18 min'},
  {id:'AL-2045',patient:'Kabir Singh',age:42,complaint:'Breathing difficulty',severity:'Attention',status:'Awaiting review',time:'26 min'},
]
export const liveAlert: Alert = {id:'alert-1',encounterId:'AL-2048',title:'Critical safety signal detected',evidence:'Severe discomfort + breathing difficulty + radiating pain'}
