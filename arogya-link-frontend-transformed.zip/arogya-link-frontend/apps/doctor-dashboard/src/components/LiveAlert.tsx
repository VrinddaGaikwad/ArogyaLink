import { AlertTriangle, X, ArrowRight } from 'lucide-react'
import type { Alert } from '../types'
export function LiveAlert({alert,onClose,onOpen}:{alert:Alert;onClose:()=>void;onOpen:()=>void}){return <div className="live-alert"><div className="alert-icon"><AlertTriangle size={20}/></div><div><span>LIVE ESCALATION</span><strong>{alert.title}</strong><p>{alert.evidence}</p></div><button onClick={onOpen}><ArrowRight size={18}/></button><button className="close" onClick={onClose}><X size={17}/></button></div>}
