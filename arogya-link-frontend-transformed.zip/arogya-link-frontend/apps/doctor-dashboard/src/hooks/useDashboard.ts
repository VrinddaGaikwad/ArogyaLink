import { useEffect, useState } from 'react'
import { encounters, liveAlert } from '../lib/mockData'
import type { Alert, Encounter } from '../types'
export function useDashboard(){
  const [selected,setSelected]=useState<Encounter>(encounters[0])
  const [alert,setAlert]=useState<Alert|null>(null)
  useEffect(()=>{const id=window.setTimeout(()=>setAlert(liveAlert),1200);return()=>clearTimeout(id)},[])
  return {encounters,selected,setSelected,alert,setAlert}
}
