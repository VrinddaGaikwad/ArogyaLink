export type Severity = 'Critical' | 'Attention' | 'Routine'
export type Encounter = { id:string; patient:string; age:number; complaint:string; severity:Severity; status:string; time:string }
export type Alert = { id:string; encounterId:string; title:string; evidence:string }
