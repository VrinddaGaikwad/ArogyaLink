import { useState } from 'react'
import { Check, ShieldCheck, User, Users } from 'lucide-react'
import { Button, GlassCard } from '../components/ui'
import { translate } from '../lib/i18n'
import type { Answerer, ConsentChoices, LanguageCode } from '../types'

export function Consent({ onAccept, language, answerer, onAnswererChange }: {
  onAccept: (choices: ConsentChoices) => void
  language: LanguageCode
  answerer: Answerer
  onAnswererChange: (a: Answerer) => void
}) {
  const t = (key: string) => translate(language, key)
  const [choices, setChoices] = useState<ConsentChoices>({ storeAnswers: false, aiSummary: false, interopExport: false })
  const toggle = (key: keyof ConsentChoices) => setChoices(c => ({ ...c, [key]: !c[key] }))
  const canContinue = choices.storeAnswers

  return <div className="center-page page-enter">
    <GlassCard className="consent-card">
      <div className="answerer-toggle" role="radiogroup" aria-label="Who is answering">
        <button role="radio" aria-checked={answerer === 'self'} className={answerer === 'self' ? 'active' : ''} onClick={() => onAnswererChange('self')}>
          <User size={16} /> I am answering for myself
        </button>
        <button role="radio" aria-checked={answerer === 'other'} className={answerer === 'other' ? 'active' : ''} onClick={() => onAnswererChange('other')}>
          <Users size={16} /> I am answering for someone else
        </button>
      </div>
      <div className="icon-disc"><ShieldCheck size={30} /></div>
      <div className="eyebrow">{t('consent.eyebrow')}</div>
      <h2>{t('consent.title')}</h2>
      <p>{t('consent.body')}</p>
      <div className="consent-checks">
        <label className="consent-check">
          <input type="checkbox" checked={choices.storeAnswers} onChange={() => toggle('storeAnswers')} />
          <span>Store my answers for this visit <em>(required)</em></span>
        </label>
        <label className="consent-check">
          <input type="checkbox" checked={choices.aiSummary} onChange={() => toggle('aiSummary')} />
          <span>Allow AI to process information for a draft clinical summary</span>
        </label>
        <label className="consent-check">
          <input type="checkbox" checked={choices.interopExport} onChange={() => toggle('interopExport')} />
          <span>Include this record in interoperable export, if requested by another provider</span>
        </label>
      </div>
      <div className="consent-points">
        {['Your information is linked to this encounter only.', 'Your doctor reviews all clinical decisions.', 'You can continue using touch input if other services fail.'].map(x => <div key={x}><Check size={17} />{x}</div>)}
      </div>
      <Button onClick={() => onAccept(choices)} disabled={!canContinue}>{t('consent.cta')} <Check size={18} /></Button>
    </GlassCard>
  </div>
}
