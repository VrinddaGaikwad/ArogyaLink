import { useRef, useState } from 'react'
import { FileUp, FileText, CheckCircle2, ArrowRight, Sparkles, AlertTriangle, RotateCcw, X, Loader2 } from 'lucide-react'
import { Button, GlassCard, EmptyState, Modal } from '../components/ui'
import type { UploadedDocument } from '../types'

const STAGE_LABEL: Record<string, string> = {
  idle: 'Waiting…',
  uploading: 'Uploading document…',
  reading: 'Reading document…',
  extracting: 'Extracting medical information…',
  checking: 'Checking information…',
  ready: 'Ready for review',
  error: "Couldn't process this file",
}

export function Documents({ documents, onAdd, onRemove, onComplete }: {
  documents: UploadedDocument[]
  onAdd: (file: File) => void
  onRemove: (id: string) => void
  onComplete: () => void
}) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)
  const [explainDoc, setExplainDoc] = useState<UploadedDocument | null>(null)

  const handleFiles = (files: FileList | null) => {
    if (!files) return
    Array.from(files).forEach(f => onAdd(f))
  }

  return <div className="documents-page page-enter">
    <div className="section-intro"><div className="eyebrow">OPTIONAL DOCUMENTS</div><h2>Anything you'd like<br /><em>your doctor to see?</em></h2></div>

    <GlassCard
      className={`upload-card ${dragging ? 'dragging' : ''}`}
      >
      <div
        onDragOver={e => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={e => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files) }}
        className="upload-dropzone"
      >
        <FileUp size={40} />
        <strong>Upload a prescription or medical report</strong>
        <span>Drag & drop, or choose a file — JPG, PNG or PDF</span>
        <Button className="secondary" onClick={() => inputRef.current?.click()}>CHOOSE FILE</Button>
        <input
          ref={inputRef}
          type="file"
          accept=".jpg,.jpeg,.png,.pdf"
          multiple
          hidden
          onChange={e => { handleFiles(e.target.files); e.target.value = '' }}
        />
      </div>
    </GlassCard>

    {documents.length === 0
      ? <EmptyState icon={<FileText size={26} />} title="No documents yet" body="Your uploaded prescriptions and reports will appear here." />
      : <div className="document-list">
        {documents.map(doc => <div className="document-item" key={doc.id}>
          <div className="document-item-head">
            <FileText size={21} />
            <div>
              <strong>{doc.name}</strong>
              <span className={`doc-stage doc-stage-${doc.stage}`}>
                {doc.stage === 'ready' ? <CheckCircle2 size={14} /> : doc.stage === 'error' ? <AlertTriangle size={14} /> : <Loader2 size={14} className="spin" />}
                {STAGE_LABEL[doc.stage]}
              </span>
            </div>
            {doc.stage === 'error'
              ? <button className="icon-btn" aria-label="Retry" onClick={() => onRemove(doc.id)}><RotateCcw size={16} /></button>
              : <button className="icon-btn" aria-label="Remove document" onClick={() => onRemove(doc.id)}><X size={16} /></button>}
          </div>

          {doc.stage === 'ready' && doc.extracted && <div className="document-extracted">
            <div className="extracted-fields">
              {doc.extracted.fields.map(f => <div key={f.label} className="extracted-field">
                <span>{f.label}</span>
                <strong>{f.value}{!f.confident && <em className="uncertain-badge"> · uncertain</em>}</strong>
              </div>)}
            </div>
            <button className="explain-link" onClick={() => setExplainDoc(doc)}><Sparkles size={14} /> Explain this</button>
          </div>}
        </div>)}
      </div>}

    <Button onClick={onComplete}>COMPLETE HEALTH CHECK <ArrowRight size={18} /></Button>

    {explainDoc && <Modal title="Let's make this simpler" onClose={() => setExplainDoc(null)}>
      <div className="explain-body">
        <div><strong>What it is</strong><p>A {explainDoc.extracted?.documentType.toLowerCase()} you uploaded, dated {explainDoc.extracted?.date}.</p></div>
        <div><strong>Why it matters</strong><p>It gives your doctor extra context alongside what you've told us today.</p></div>
        <div><strong>What we could read from it</strong><p>{explainDoc.extracted?.fields.filter(f => f.confident).map(f => f.value).join(', ') || 'Basic file details only.'}</p></div>
        <div><strong>What to discuss with your doctor</strong><p>Bring the original document — your doctor will confirm anything the system was uncertain about.</p></div>
      </div>
      <p className="explain-footer">AI-assisted explanation • Not a diagnosis</p>
    </Modal>}
  </div>
}
