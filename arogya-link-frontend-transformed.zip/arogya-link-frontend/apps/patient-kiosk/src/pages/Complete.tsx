import { CheckCircle2, HeartHandshake, AlertTriangle } from 'lucide-react'
import type { ActiveRedFlag } from '../types'

export function Complete({ encounterId, redFlags }: { encounterId?: string; redFlags: ActiveRedFlag[] }) {
  return <div className="complete-page page-enter">
    <div className={`complete-glow ${redFlags.length ? 'complete-glow-alert' : ''}`}>
      {redFlags.length ? <AlertTriangle size={72} /> : <CheckCircle2 size={72} />}
    </div>
    <div className="eyebrow">ENCOUNTER RECORDED</div>
    <h2>You're all set.</h2>
    <p>
      {redFlags.length
        ? 'Your information is ready for clinical review. Because of what you shared, the care team has been notified for a prompt review.'
        : 'Your information is ready for clinical review. If urgent attention is needed, the care team has been notified.'}
    </p>
    <div className="encounter-id"><HeartHandshake size={18} /> Encounter #{encounterId?.slice(0, 8).toUpperCase()}</div>
  </div>
}
