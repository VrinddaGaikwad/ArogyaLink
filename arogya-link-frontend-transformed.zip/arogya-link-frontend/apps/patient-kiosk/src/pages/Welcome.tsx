import { ArrowRight, Sparkles } from 'lucide-react'
import { Button } from '../components/ui'
import { LanguageSelect } from '../components/LanguageSelect'
import { translate } from '../lib/i18n'
import type { LanguageCode } from '../types'

export function Welcome({ onStart, language, onLanguageChange }: {
  onStart: () => void
  language: LanguageCode
  onLanguageChange: (lang: LanguageCode) => void
}) {
  const t = (key: string) => translate(language, key)
  return <div className="hero-page page-enter">
    <div className="hero-copy">
      <div className="eyebrow"><Sparkles size={15} /> {t('welcome.eyebrow')}</div>
      <h1>{t('welcome.title.line1')}<br /><em>{t('welcome.title.em')}</em> {t('welcome.title.line2')}</h1>
      <p>{t('welcome.body')}</p>
      <div className="hero-actions">
        <Button onClick={onStart}>{t('welcome.cta')} <ArrowRight size={18} /></Button>
        <LanguageSelect current={language} onChange={onLanguageChange} />
      </div>
    </div>
    <div className="hero-visual" aria-hidden="true">
      <div className="orb orb-one" /><div className="orb orb-two" />
      <div className="care-card">
        <span className="pulse">⌁</span>
        <small>{t('welcome.card.label')}</small>
        <strong>{t('welcome.card.title').split('\n').map((line, i) => <span key={i}>{line}<br /></span>)}</strong>
      </div>
      <div className="floating-chip">{t('welcome.chip')}</div>
    </div>
    <div className="hero-footer"><span>01</span><i /><span>04</span></div>
  </div>
}
