import { HeartPulse, Wind, Thermometer, MoreHorizontal, Users } from 'lucide-react'
import { complaintOptions } from '../data/patientDemoData'
import { GlassCard } from '../components/ui'
import { translate } from '../lib/i18n'
import type { Answerer, LanguageCode } from '../types'

const icons: Record<string, typeof HeartPulse> = {
  chest: HeartPulse,
  breathing: Wind,
  fever: Thermometer,
  other: MoreHorizontal,
}

export function Complaint({ onSelect, language, answerer }: {
  onSelect: (id: string, label: string) => void
  language: LanguageCode
  answerer: Answerer
}) {
  const t = (key: string) => translate(language, key)
  return <div className="choice-page page-enter">
    {answerer === 'other' && <div className="caregiver-banner"><Users size={15} /> Answering on behalf of someone else</div>}
    <div className="section-intro"><div className="eyebrow">{t('complaint.eyebrow')}</div><h2>{t('complaint.title.line1')}<br /><em>{t('complaint.title.em')}</em></h2><p>{t('complaint.body')}</p></div>
    <div className="complaint-grid">
      {complaintOptions.map((item, index) => {
        const Icon = icons[item.id] ?? MoreHorizontal
        return <GlassCard key={item.id} className="choice-card">
          <button onClick={() => onSelect(item.id, item.label)} style={{ animationDelay: `${index * 70}ms` }}>
            <span className="choice-icon"><Icon size={26} /></span>
            <strong>{item.label}</strong>
            <span className="choice-desc">{item.description}</span>
          </button>
        </GlassCard>
      })}
    </div>
  </div>
}
