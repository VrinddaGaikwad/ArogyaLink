import { useEffect, useState } from 'react'
import { ArrowRight } from 'lucide-react'
import { Button, Progress } from '../components/ui'
import { VoiceRecorder } from '../components/VoiceRecorder'
import { RedFlagBanner } from '../components/RedFlagBanner'
import { useReducedMotion } from '../hooks/useReducedMotion'
import type { ActiveRedFlag, Answer, Question } from '../types'

export function Intake({ index, questions, onAnswer, onDocuments, redFlags, onVoiceMiss }: {
  index: number
  questions: Question[]
  onAnswer: (id: string, value: Answer['value'], source?: Answer['source']) => void
  onDocuments: () => void
  redFlags: ActiveRedFlag[]
  onVoiceMiss: () => void
}) {
  const reducedMotion = useReducedMotion()
  const [textDraft, setTextDraft] = useState('')

  useEffect(() => { setTextDraft('') }, [index])

  if (!questions.length) return null
  if (index >= questions.length) { onDocuments(); return null }
  const q: Question = questions[index]

  const matchOption = (transcript: string): string | null => {
    const cleaned = transcript.trim().toLowerCase()
    return q.options?.find(opt => cleaned.startsWith(opt.toLowerCase())) ?? null
  }

  return <div className="question-page page-enter" key={q.id}>
    <Progress current={index + 1} total={questions.length} label="Building your health picture" />
    <RedFlagBanner flags={redFlags} />
    <div className={`question-main ${reducedMotion ? '' : 'question-anim'}`}>
      <div className="eyebrow">LET'S UNDERSTAND BETTER</div>
      <h2>{q.text}</h2>

      {q.type === 'scale' && <div className="scale-row">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => <button key={n} onClick={() => onAnswer(q.id, n)}>{n}</button>)}
      </div>}

      {q.type === 'choice' && <div className="answer-list">
        {q.options?.map(option => <button key={option} onClick={() => onAnswer(q.id, option)}>{option}<ArrowRight size={19} /></button>)}
      </div>}

      {q.type === 'text' && <div className="text-answer">
        <textarea
          value={textDraft}
          onChange={e => setTextDraft(e.target.value)}
          placeholder="Type your answer here…"
          rows={3}
          aria-label={q.text}
        />
        <Button onClick={() => onAnswer(q.id, textDraft, 'touch')} disabled={!textDraft.trim()}>
          CONTINUE <ArrowRight size={16} />
        </Button>
      </div>}
    </div>

    <VoiceRecorder onConfirm={transcript => {
      if (q.type === 'text') { setTextDraft(transcript); return }
      const matched = matchOption(transcript)
      if (matched) onAnswer(q.id, matched, 'voice')
      else onVoiceMiss()
    }} />
  </div>
}
