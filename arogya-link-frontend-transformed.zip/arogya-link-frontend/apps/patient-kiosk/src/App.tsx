import type { ReactElement } from 'react'
import { KioskLayout } from './components/Layout'
import { useIntake } from './hooks/useIntake'
import { Welcome } from './pages/Welcome'
import { Consent } from './pages/Consent'
import { Complaint } from './pages/Complaint'
import { Intake } from './pages/Intake'
import { Documents } from './pages/Documents'
import { Complete } from './pages/Complete'
import type { IntakeStep } from './types'

const STEP_DOT: Record<IntakeStep, number> = { welcome: 0, consent: 1, complaint: 2, intake: 3, documents: 4, complete: 4 }

export function App() {
  const intake = useIntake()
  const { step, session, questionIndex, questions, goBack, pushToast } = intake

  const pages: Record<IntakeStep, ReactElement> = {
    welcome: <Welcome
      onStart={intake.start}
      language={session?.language ?? 'en'}
      onLanguageChange={intake.setLanguage}
    />,
    consent: <Consent
      onAccept={intake.consent}
      language={session?.language ?? 'en'}
      answerer={session?.answerer ?? 'self'}
      onAnswererChange={intake.setAnswerer}
    />,
    complaint: <Complaint
      onSelect={intake.chooseComplaint}
      language={session?.language ?? 'en'}
      answerer={session?.answerer ?? 'self'}
    />,
    intake: <Intake
      index={questionIndex}
      questions={questions}
      onAnswer={intake.answer}
      onDocuments={() => intake.setStep('documents')}
      redFlags={session?.redFlags ?? []}
      onVoiceMiss={() => pushToast("We couldn't match that to an option — please try again or tap one.", 'error')}
    />,
    documents: <Documents
      documents={session?.documents ?? []}
      onAdd={intake.addDocument}
      onRemove={intake.removeDocument}
      onComplete={intake.complete}
    />,
    complete: <Complete encounterId={session?.encounterId} redFlags={session?.redFlags ?? []} />,
  }

  return <KioskLayout
    step={STEP_DOT[step]}
    onBack={step !== 'welcome' && step !== 'complete' ? goBack : undefined}
    toasts={intake.toasts}
    onDismissToast={intake.dismissToast}
  >
    {pages[step]}
  </KioskLayout>
}
