import { useState } from 'react'
import { Languages, Check } from 'lucide-react'
import { Modal } from './ui'
import { supportedLanguages } from '../data/patientDemoData'
import type { LanguageCode } from '../types'

export function LanguageSelect({ current, onChange }: { current: LanguageCode; onChange: (lang: LanguageCode) => void }) {
  const [open, setOpen] = useState(false)
  const currentLabel = supportedLanguages.find(l => l.code === current)?.native ?? 'English'
  return <>
    <button className="language" onClick={() => setOpen(true)}>
      <Languages size={18} /> {currentLabel} ▾
    </button>
    {open && <Modal title="Choose your language" onClose={() => setOpen(false)}>
      <div className="language-grid">
        {supportedLanguages.map(l => <button
          key={l.code}
          className={`language-option ${l.code === current ? 'selected' : ''}`}
          onClick={() => { onChange(l.code); setOpen(false) }}
        >
          <span>{l.native}</span>
          <small>{l.label}</small>
          {l.code === current && <Check size={16} />}
        </button>)}
      </div>
    </Modal>}
  </>
}
