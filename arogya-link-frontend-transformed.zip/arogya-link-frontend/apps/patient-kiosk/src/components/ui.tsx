import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { useEffect, useRef } from 'react'
import { AlertTriangle, CheckCircle2, Info, X } from 'lucide-react'
import type { ToastMessage } from '../types'

export function Button({ children, className = '', ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button className={`btn ${className}`} {...props}>{children}</button>
}

export function GlassCard({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`glass-card ${className}`}>{children}</section>
}

export function Progress({ current, total, label }: { current: number; total: number; label?: string }) {
  return <div className="progress-wrap" role="progressbar" aria-valuenow={current} aria-valuemin={1} aria-valuemax={total} aria-label={label ?? `Step ${current} of ${total}`}>
    <div className="progress"><span style={{ width: `${Math.max(8, (current / total) * 100)}%` }} /></div>
    <span>{current} / {total}</span>
  </div>
}

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} aria-hidden="true" />
}

export function EmptyState({ icon, title, body }: { icon: ReactNode; title: string; body: string }) {
  return <div className="empty-state">
    <div className="empty-icon">{icon}</div>
    <strong>{title}</strong>
    <p>{body}</p>
  </div>
}

const toastIcon = { success: <CheckCircle2 size={18} />, info: <Info size={18} />, error: <AlertTriangle size={18} /> }

export function ToastStack({ toasts, onDismiss }: { toasts: ToastMessage[]; onDismiss: (id: string) => void }) {
  return <div className="toast-stack" role="status" aria-live="polite">
    {toasts.map(t => <div key={t.id} className={`toast toast-${t.kind}`}>
      {toastIcon[t.kind]}<span>{t.text}</span>
      <button aria-label="Dismiss notification" onClick={() => onDismiss(t.id)}><X size={14} /></button>
    </div>)}
  </div>
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', onKey)
    ref.current?.focus()
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])
  return <div className="modal-overlay" role="presentation" onClick={onClose}>
    <div
      className="modal-panel"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      tabIndex={-1}
      ref={ref}
      onClick={e => e.stopPropagation()}
    >
      <div className="modal-head">
        <strong>{title}</strong>
        <button aria-label="Close" onClick={onClose}><X size={18} /></button>
      </div>
      <div className="modal-body">{children}</div>
    </div>
  </div>
}
