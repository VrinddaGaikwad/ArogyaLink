import type { ReactNode } from 'react'
import { HeartPulse, Wifi, WifiOff, ShieldCheck, ChevronLeft } from 'lucide-react'
import { useEffect, useState } from 'react'
import { ToastStack } from './ui'
import type { ToastMessage } from '../types'

export function KioskLayout({ children, step, onBack, toasts, onDismissToast }: {
  children: ReactNode
  step: number
  onBack?: () => void
  toasts: ToastMessage[]
  onDismissToast: (id: string) => void
}) {
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine)
  useEffect(() => {
    const goOnline = () => setOnline(true)
    const goOffline = () => setOnline(false)
    window.addEventListener('online', goOnline)
    window.addEventListener('offline', goOffline)
    return () => { window.removeEventListener('online', goOnline); window.removeEventListener('offline', goOffline) }
  }, [])

  return <main className="kiosk-shell">
    <header className="kiosk-header">
      <div className="header-left">
        {onBack && <button className="back-btn" onClick={onBack} aria-label="Go back"><ChevronLeft size={18} /></button>}
        <div className="brand"><span className="brand-mark"><HeartPulse size={20} /></span><b>AROGYA</b> LINK</div>
      </div>
      <div className="header-meta">
        <span><ShieldCheck size={15} /> Private</span>
        <span className={online ? '' : 'offline'}>{online ? <Wifi size={15} /> : <WifiOff size={15} />} {online ? 'Connected' : 'Offline'}</span>
      </div>
    </header>
    <div className="step-dots" aria-hidden="true">{[0, 1, 2, 3, 4].map(i => <i key={i} className={i <= step ? 'active' : ''} />)}</div>
    {!online && <div className="offline-banner" role="status">Offline mode — your answers are saved on this device and will sync when connection returns.</div>}
    <div className="page-stage">{children}</div>
    <ToastStack toasts={toasts} onDismiss={onDismissToast} />
  </main>
}
