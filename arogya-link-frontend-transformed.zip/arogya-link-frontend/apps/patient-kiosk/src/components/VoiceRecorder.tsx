import { useEffect, useRef, useState } from 'react'
import { Mic, RotateCcw, Check, Square } from 'lucide-react'
import { Button } from './ui'

type Phase = 'idle' | 'listening' | 'review'

const DEMO_TRANSCRIPTS = [
  "I've had this discomfort since this morning, it comes and goes.",
  "It gets worse when I walk up the stairs.",
  "I haven't taken anything for it yet.",
]

// Uses the real browser Web Speech API when available (Chrome/Edge). When it
// isn't supported, falls back to an honestly-labelled demo transcript so the
// interaction can still be reviewed end-to-end offline.
export function VoiceRecorder({ onConfirm }: { onConfirm: (transcript: string) => void }) {
  const [phase, setPhase] = useState<Phase>('idle')
  const [transcript, setTranscript] = useState('')
  const [supported, setSupported] = useState(true)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  useEffect(() => {
    const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition
    setSupported(Boolean(Ctor))
  }, [])

  const start = () => {
    const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition
    setTranscript('')
    setPhase('listening')
    if (!Ctor) {
      window.setTimeout(() => {
        setTranscript(DEMO_TRANSCRIPTS[Math.floor(Math.random() * DEMO_TRANSCRIPTS.length)])
        setPhase('review')
      }, 1400)
      return
    }
    const recognition = new Ctor()
    recognition.lang = 'en-IN'
    recognition.continuous = false
    recognition.interimResults = true
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let text = ''
      for (let i = 0; i < event.results.length; i++) text += event.results[i][0].transcript
      setTranscript(text)
    }
    recognition.onerror = () => setPhase('idle')
    recognition.onend = () => setPhase(current => current === 'listening' ? 'review' : current)
    recognitionRef.current = recognition
    recognition.start()
  }

  const stop = () => {
    recognitionRef.current?.stop()
    setPhase(current => current === 'listening' ? (transcript ? 'review' : 'idle') : current)
  }

  if (phase === 'idle') {
    return <button className="voice-btn" onClick={start} aria-label="Answer using your voice">
      <Mic size={19} /><span>Answer using your voice</span>
      <small>{supported ? 'Optional' : 'Demo mode'}</small>
    </button>
  }

  if (phase === 'listening') {
    return <div className="voice-panel" role="status" aria-live="polite">
      <div className="voice-wave" aria-hidden="true">{Array.from({ length: 9 }).map((_, i) => <span key={i} style={{ animationDelay: `${i * 70}ms` }} />)}</div>
      <strong>Listening…</strong>
      <p>Tell us what you're experiencing.</p>
      <Button className="secondary" onClick={stop}><Square size={16} /> Stop</Button>
    </div>
  }

  return <div className="voice-panel voice-review">
    <div className="eyebrow">WE HEARD</div>
    <p className="voice-transcript">"{transcript || '…'}"</p>
    <p className="voice-confirm-q">Is this correct?</p>
    <div className="voice-actions">
      <Button className="secondary" onClick={start}><RotateCcw size={16} /> Try again</Button>
      <Button onClick={() => { onConfirm(transcript); setPhase('idle') }} disabled={!transcript}><Check size={16} /> Use this</Button>
    </div>
  </div>
}
