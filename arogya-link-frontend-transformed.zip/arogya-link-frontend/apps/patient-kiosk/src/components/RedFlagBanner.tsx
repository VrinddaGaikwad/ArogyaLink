import { useState } from 'react'
import { AlertTriangle, ChevronDown } from 'lucide-react'
import { Modal } from './ui'
import type { ActiveRedFlag } from '../types'

// Calm, non-alarming safety banner. Never states a diagnosis — only that
// something in the patient's answers may need prompt clinical review, with
// a plain-language "why am I seeing this" explanation on demand.
export function RedFlagBanner({ flags }: { flags: ActiveRedFlag[] }) {
  const [openId, setOpenId] = useState<string | null>(null)
  if (flags.length === 0) return null
  const active = flags.find(f => f.id === openId) ?? null
  return <>
    <div className="redflag-banner" role="alert">
      <div className="redflag-icon"><AlertTriangle size={20} /></div>
      <div className="redflag-copy">
        <strong>We noticed something that may need prompt medical attention.</strong>
        <p>Your answers indicate symptoms that should be reviewed by a healthcare professional. Please tell a staff member if you feel this is worsening.</p>
        <div className="redflag-links">
          {flags.map(f => <button key={f.id} onClick={() => setOpenId(f.id)}>
            Why this alert? <ChevronDown size={14} />
          </button>)}
        </div>
      </div>
    </div>
    {active && <Modal title="Why this alert?" onClose={() => setOpenId(null)}>
      <p className="modal-lead">{active.reason}</p>
      <p className="modal-note">Your symptoms may require urgent clinical evaluation. This is not a diagnosis — your doctor will review your full information and decide the next step.</p>
    </Modal>}
  </>
}
