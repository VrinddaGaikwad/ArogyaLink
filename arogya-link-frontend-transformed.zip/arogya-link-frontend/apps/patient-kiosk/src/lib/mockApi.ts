import type { Answer, ActiveRedFlag, PatientSession, RedFlagRule, UploadedDocument, UploadStage } from '../types'
import { redFlagRules } from '../data/patientDemoData'

const delay = (ms = 350) => new Promise(resolve => setTimeout(resolve, ms))

export async function createSession(): Promise<PatientSession> {
  await delay()
  return {
    encounterId: crypto.randomUUID(),
    consented: false,
    answerer: 'self',
    language: 'en',
    answers: [],
    redFlags: [],
    documents: [],
  }
}

export async function saveConsent(): Promise<void> { await delay(250) }

export async function saveAnswer(_answer: Answer): Promise<void> { await delay(220) }

export async function finishEncounter(): Promise<void> { await delay(500) }

// Mirrors what a backend red-flag rule engine would return: given an answer,
// which (if any) rules matched. Kept centralized so the UI never invents a
// clinical judgement of its own.
export function evaluateRedFlags(answer: Answer): RedFlagRule[] {
  return redFlagRules.filter(rule => rule.questionId === answer.questionId && rule.matchValue === answer.value)
}

export function toActiveRedFlag(rule: RedFlagRule): ActiveRedFlag {
  return { ...rule, triggeredAt: new Date().toISOString() }
}

const STAGE_SEQUENCE: { stage: UploadStage; ms: number }[] = [
  { stage: 'uploading', ms: 600 },
  { stage: 'reading', ms: 700 },
  { stage: 'extracting', ms: 900 },
  { stage: 'checking', ms: 500 },
  { stage: 'ready', ms: 0 },
]

// Simulates an upload -> OCR -> extraction pipeline against a document,
// invoking onStage as each phase completes so the UI can show real
// progressive states rather than a single spinner. No values are invented
// beyond a clearly-labelled demo extraction (this stands in for the real
// OCR/NLP backend service).
export async function processDocument(
  file: File,
  onStage: (stage: UploadStage) => void
): Promise<UploadedDocument['extracted']> {
  for (const step of STAGE_SEQUENCE) {
    onStage(step.stage)
    if (step.ms) await delay(step.ms)
  }
  const isImageOrPdf = /\.(pdf|jpg|jpeg|png)$/i.test(file.name)
  if (!isImageOrPdf) {
    onStage('error')
    throw new Error('Unsupported file type')
  }
  return {
    documentType: /report|test|lab/i.test(file.name) ? 'Lab report' : 'Medical document',
    date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
    fields: [
      { label: 'Document name', value: file.name, confident: true },
      { label: 'File size', value: `${Math.max(1, Math.round(file.size / 1024))} KB`, confident: true },
      { label: 'Extracted summary', value: 'Demo extraction — connect OCR service for real values', confident: false },
    ],
  }
}
