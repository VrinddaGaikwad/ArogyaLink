import type { Question } from '../types'

export const complaintOptions = [
  { id: 'chest', label: 'Chest discomfort', icon: '♥' },
  { id: 'breathing', label: 'Breathing difficulty', icon: '◌' },
  { id: 'fever', label: 'Fever or weakness', icon: '☼' },
  { id: 'other', label: 'Something else', icon: '+' },
]

export const demoQuestions: Question[] = [
  { id: 'severity', text: 'How severe is your discomfort?', type: 'scale' },
  { id: 'breathlessness', text: 'Are you experiencing difficulty breathing?', type: 'choice', options: ['Yes', 'No'] },
  { id: 'radiation', text: 'Does the discomfort spread to your arm, jaw, or back?', type: 'choice', options: ['Yes', 'No'] },
  { id: 'duration', text: 'When did this begin?', type: 'choice', options: ['Just now', 'Within a few hours', 'Today', 'Earlier'] },
]
