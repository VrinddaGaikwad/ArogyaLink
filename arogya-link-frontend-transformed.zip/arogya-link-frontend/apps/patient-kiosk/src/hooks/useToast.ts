import { useCallback, useRef, useState } from 'react'
import type { ToastKind, ToastMessage } from '../types'

export function useToast() {
  const [toasts, setToasts] = useState<ToastMessage[]>([])
  const counter = useRef(0)

  const dismiss = useCallback((id: string) => {
    setToasts(current => current.filter(t => t.id !== id))
  }, [])

  const push = useCallback((text: string, kind: ToastKind = 'info') => {
    const id = `toast-${++counter.current}`
    setToasts(current => [...current, { id, kind, text }])
    window.setTimeout(() => dismiss(id), 4000)
  }, [dismiss])

  return { toasts, push, dismiss }
}
