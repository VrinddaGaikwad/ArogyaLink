import { useCallback, useMemo, useState } from 'react'
import { createSession, evaluateRedFlags, finishEncounter, processDocument, saveAnswer, saveConsent, toActiveRedFlag } from '../lib/mockApi'
import { questionBank } from '../data/patientDemoData'
import type { Answer, Answerer, ConsentChoices, IntakeStep, LanguageCode, PatientSession, Question, UploadedDocument } from '../types'
import { useToast } from './useToast'

const STEP_ORDER: IntakeStep[] = ['welcome', 'consent', 'complaint', 'intake', 'documents', 'complete']

export function useIntake() {
  const [step, setStep] = useState<IntakeStep>('welcome')
  const [session, setSession] = useState<PatientSession | null>(null)
  const [questionIndex, setQuestionIndex] = useState(0)
  const [loading, setLoading] = useState(false)
  const toast = useToast()

  const questions: Question[] = useMemo(() => {
    if (!session?.complaintId) return []
    return questionBank[session.complaintId] ?? questionBank.other
  }, [session?.complaintId])

  const start = useCallback(async () => {
    setLoading(true)
    try {
      const created = await createSession()
      setSession(created)
      setStep('consent')
    } finally {
      setLoading(false)
    }
  }, [])

  const setLanguage = useCallback((language: LanguageCode) => {
    setSession(current => current ? { ...current, language } : current)
  }, [])

  const setAnswerer = useCallback((answerer: Answerer) => {
    setSession(current => current ? { ...current, answerer } : current)
  }, [])

  const consent = useCallback(async (choices: ConsentChoices) => {
    setSession(current => current ? { ...current, consented: true, consentChoices: choices } : current)
    await saveConsent()
    setStep('complaint')
  }, [])

  const chooseComplaint = useCallback((complaintId: string, label: string) => {
    setSession(current => current ? { ...current, complaint: label, complaintId } : current)
    setQuestionIndex(0)
    setStep('intake')
  }, [])

  const answer = useCallback(async (questionId: string, value: Answer['value'], source: Answer['source'] = 'touch') => {
    const item: Answer = { questionId, value, source, timestamp: new Date().toISOString() }
    const matched = evaluateRedFlags(item)
    setSession(current => {
      if (!current) return current
      const newFlags = matched
        .filter(rule => !current.redFlags.some(f => f.id === rule.id))
        .map(toActiveRedFlag)
      return {
        ...current,
        answers: [...current.answers, item],
        redFlags: newFlags.length ? [...current.redFlags, ...newFlags] : current.redFlags,
      }
    })
    await saveAnswer(item)
    setQuestionIndex(index => index + 1)
  }, [])

  const addDocument = useCallback((file: File) => {
    const doc: UploadedDocument = {
      id: crypto.randomUUID(),
      name: file.name,
      sizeKb: Math.max(1, Math.round(file.size / 1024)),
      stage: 'idle',
    }
    setSession(current => current ? { ...current, documents: [...current.documents, doc] } : current)

    const updateDoc = (patch: Partial<UploadedDocument>) => {
      setSession(current => current ? {
        ...current,
        documents: current.documents.map(d => d.id === doc.id ? { ...d, ...patch } : d),
      } : current)
    }

    processDocument(file, stage => updateDoc({ stage }))
      .then(extracted => {
        updateDoc({ stage: 'ready', extracted })
        toast.push(`${file.name} processed successfully.`, 'success')
      })
      .catch(() => {
        updateDoc({ stage: 'error' })
        toast.push(`We couldn't process ${file.name}. You can try again.`, 'error')
      })
  }, [toast])

  const removeDocument = useCallback((id: string) => {
    setSession(current => current ? { ...current, documents: current.documents.filter(d => d.id !== id) } : current)
  }, [])

  const complete = useCallback(async () => {
    setLoading(true)
    try {
      await finishEncounter()
      setStep('complete')
    } finally {
      setLoading(false)
    }
  }, [])

  const goBack = useCallback(() => {
    const idx = STEP_ORDER.indexOf(step)
    if (idx > 0) {
      const prev = STEP_ORDER[idx - 1]
      if (prev === 'welcome') return
      setStep(prev)
    }
  }, [step])

  return {
    step, setStep, session, questionIndex, questions, loading,
    start, consent, chooseComplaint, answer, goBack,
    setLanguage, setAnswerer, addDocument, removeDocument, complete,
    toasts: toast.toasts, dismissToast: toast.dismiss, pushToast: toast.push,
  }
}
