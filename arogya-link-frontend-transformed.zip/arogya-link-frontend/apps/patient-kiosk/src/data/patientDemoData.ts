// Centralized demo/clinical-content data layer.
// Nothing here is real patient data — question banks and red-flag rules are
// illustrative content for the SIH demo and can be swapped for the FastAPI
// adaptive-questionnaire + red-flag-engine endpoints without touching the UI.
import type { ComplaintOption, Question, RedFlagRule } from '../types'

export const complaintOptions: ComplaintOption[] = [
  { id: 'chest', label: 'Chest discomfort', description: 'Pain, pressure or tightness in the chest' },
  { id: 'breathing', label: 'Breathing difficulty', description: 'Shortness of breath or trouble breathing' },
  { id: 'fever', label: 'Fever or weakness', description: 'High temperature, chills or fatigue' },
  { id: 'other', label: 'Something else', description: "Describe what you're experiencing in your own words" },
]

export const questionBank: Record<string, Question[]> = {
  chest: [
    { id: 'severity', text: 'How severe is your discomfort right now?', type: 'scale' },
    { id: 'breathlessness', text: 'Are you experiencing difficulty breathing along with this?', type: 'choice', options: ['Yes', 'No'] },
    { id: 'radiation', text: 'Does the discomfort spread to your arm, jaw, or back?', type: 'choice', options: ['Yes', 'No'] },
    { id: 'sweating', text: 'Have you noticed cold sweat or nausea with this?', type: 'choice', options: ['Yes', 'No'] },
    { id: 'duration', text: 'When did this begin?', type: 'choice', options: ['Just now', 'Within a few hours', 'Today', 'Earlier'] },
  ],
  breathing: [
    { id: 'severity', text: 'How severe is the breathing difficulty?', type: 'scale' },
    { id: 'rest', text: 'Does it happen even while you are resting?', type: 'choice', options: ['Yes', 'No'] },
    { id: 'chestpain', text: 'Is there any chest pain along with it?', type: 'choice', options: ['Yes', 'No'] },
    { id: 'duration', text: 'When did this begin?', type: 'choice', options: ['Just now', 'Within a few hours', 'Today', 'Earlier'] },
  ],
  fever: [
    { id: 'severity', text: "How would you rate how unwell you're feeling?", type: 'scale' },
    { id: 'temperature', text: 'Do you know roughly how high your temperature is?', type: 'choice', options: ['Mild', 'High', 'Not sure'] },
    { id: 'breathlessness', text: 'Any difficulty breathing along with the fever?', type: 'choice', options: ['Yes', 'No'] },
    { id: 'duration', text: 'How long have you had this fever?', type: 'choice', options: ['Since today', '2–3 days', 'Longer than 3 days'] },
  ],
  other: [
    { id: 'severity', text: "How would you rate how you're feeling overall?", type: 'scale' },
    { id: 'description', text: 'In a few words, what are you experiencing?', type: 'text' },
    { id: 'duration', text: 'When did this begin?', type: 'choice', options: ['Just now', 'Within a few hours', 'Today', 'Earlier'] },
  ],
}

// A rule fires when a specific answer is given. In production this logic
// lives in the backend red-flag engine — the frontend only renders whatever
// it is told, in plain language, with a "why am I seeing this" explanation.
export const redFlagRules: RedFlagRule[] = [
  { id: 'cardiac-radiation', questionId: 'radiation', matchValue: 'Yes', title: 'Symptoms that may need prompt attention', reason: 'Your answers included chest discomfort that spreads to your arm, jaw, or back.' },
  { id: 'cardiac-breathless', questionId: 'breathlessness', matchValue: 'Yes', title: 'Symptoms that may need prompt attention', reason: 'Your answers included breathing difficulty alongside your other symptoms.' },
  { id: 'resp-rest', questionId: 'rest', matchValue: 'Yes', title: 'Breathing difficulty at rest', reason: 'You indicated the breathing difficulty happens even while resting.' },
]

export const supportedLanguages: { code: 'en' | 'hi' | 'mr'; label: string; native: string }[] = [
  { code: 'en', label: 'English', native: 'English' },
  { code: 'hi', label: 'Hindi', native: 'हिन्दी' },
  { code: 'mr', label: 'Marathi', native: 'मराठी' },
]
