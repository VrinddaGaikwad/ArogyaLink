export type AnswerValue = string | number | boolean
export type Answer = { questionId: string; value: AnswerValue; source: 'touch' | 'voice'; timestamp: string }

export type QuestionType = 'choice' | 'scale' | 'text'
export type Question = {
  id: string
  text: string
  type: QuestionType
  options?: string[]
}

export type ComplaintOption = {
  id: string
  label: string
  description: string
}

export type RedFlagRule = {
  id: string
  questionId: string
  matchValue: AnswerValue
  title: string
  reason: string
}

export type ActiveRedFlag = RedFlagRule & { triggeredAt: string }

export type Answerer = 'self' | 'other'
export type LanguageCode = 'en' | 'hi' | 'mr'

export type ConsentChoices = {
  storeAnswers: boolean
  aiSummary: boolean
  interopExport: boolean
}

export type UploadStage = 'idle' | 'uploading' | 'reading' | 'extracting' | 'checking' | 'ready' | 'error'

export type UploadedDocument = {
  id: string
  name: string
  sizeKb: number
  stage: UploadStage
  extracted?: {
    documentType: string
    date: string
    fields: { label: string; value: string; confident: boolean }[]
  }
}

export type IntakeStep = 'welcome' | 'consent' | 'complaint' | 'intake' | 'documents' | 'complete'

export type PatientSession = {
  encounterId: string
  consented: boolean
  consentChoices?: ConsentChoices
  complaint?: string
  complaintId?: string
  answerer: Answerer
  language: LanguageCode
  answers: Answer[]
  redFlags: ActiveRedFlag[]
  documents: UploadedDocument[]
}

export type ToastKind = 'success' | 'info' | 'error'
export type ToastMessage = { id: string; kind: ToastKind; text: string }
