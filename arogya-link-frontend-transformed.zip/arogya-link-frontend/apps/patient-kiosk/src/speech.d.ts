// Minimal ambient types for the Web Speech API (not in default TS DOM libs).
interface SpeechRecognitionResultItem { transcript: string; confidence: number }
interface SpeechRecognitionResult { 0: SpeechRecognitionResultItem; isFinal: boolean; length: number }
interface SpeechRecognitionResultList { length: number; item(i: number): SpeechRecognitionResult; [index: number]: SpeechRecognitionResult }
interface SpeechRecognitionEvent extends Event { resultIndex: number; results: SpeechRecognitionResultList }
interface SpeechRecognitionErrorEvent extends Event { error: string }
interface SpeechRecognition extends EventTarget {
  lang: string
  continuous: boolean
  interimResults: boolean
  start(): void
  stop(): void
  onresult: ((event: SpeechRecognitionEvent) => void) | null
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null
  onend: (() => void) | null
}
interface Window {
  SpeechRecognition?: { new(): SpeechRecognition }
  webkitSpeechRecognition?: { new(): SpeechRecognition }
}
